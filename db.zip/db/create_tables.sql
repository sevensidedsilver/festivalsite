create table IF NOT EXISTS users
(id text,
 username text,
 admin integer);


 
