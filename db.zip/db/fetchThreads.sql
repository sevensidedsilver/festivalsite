select * from threads
-- join users on threads.author_id = users.user_id
