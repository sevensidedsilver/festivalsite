update threads
set reported = 0
where thread_id = $1
