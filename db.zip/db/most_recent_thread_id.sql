select max(thread_id) from threads
