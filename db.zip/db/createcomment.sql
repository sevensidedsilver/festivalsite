insert into comments (thread_id, parent_comment, author_display, comment_content, created_at)
  values ($1, $2, $3, $4, $5)
