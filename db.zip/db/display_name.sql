UPDATE users
SET display_name = "testVALUE",

WHERE condition;
