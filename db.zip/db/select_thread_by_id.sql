select * from threads
where thread_id = $1
