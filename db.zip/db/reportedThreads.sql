select * from threads
where reported = 1
