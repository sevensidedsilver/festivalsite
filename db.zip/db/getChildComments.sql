select * from comments
where parent_comment = $1;
