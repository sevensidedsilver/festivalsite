update comments
set reported = 1
where comment_id = $1
