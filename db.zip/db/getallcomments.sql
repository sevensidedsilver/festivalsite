select * from comments
where thread_id = $1
