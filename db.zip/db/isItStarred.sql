select starred_threads from users
where id = $1
