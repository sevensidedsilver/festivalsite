update comments
set reported = 0
where comment_id = $1
