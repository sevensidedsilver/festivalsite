insert into users (id, username, admin)
values($1, $2, $3)
