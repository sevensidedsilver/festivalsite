delete from comments
where comment_id = $1
