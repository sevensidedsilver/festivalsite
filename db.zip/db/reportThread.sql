update threads
set reported = 1
where thread_id = $1
